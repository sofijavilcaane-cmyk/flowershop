Puķu veikala mājaslapa

Mapju izkārtojums:
flowershop_project_final/
  app.py
  flowershop.db
  create_database.sql
  templates/
  static/
    style.css
    images/
      roze.jpg
      lilija.jpg
      tulpe.jpg
      orhideja.jpg

DBeaver datubāzē ir 4 tabulas:
1. categories
2. flowers
3. occasions
4. flower_occasions

Savienojumi:
flowers.category_id -> categories.id
flower_occasions.flower_id -> flowers.id
flower_occasions.occasion_id -> occasions.id

Palaišana VS Code:
1. Atver projekta mapi VS Code.
2. Terminālī ieraksti: py -m pip install flask
3. Terminālī ieraksti: py app.py
4. Atver pārlūkā: http://127.0.0.1:5000

Mājaslapā augšā nav sadaļas “Kategorijas”.
Notikumu lapā var uzklikšķināt uz notikuma un redzēt tam piemērotās puķes.
