PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS flower_occasions;
DROP TABLE IF EXISTS flowers;
DROP TABLE IF EXISTS occasions;
DROP TABLE IF EXISTS categories;

CREATE TABLE categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL
);

CREATE TABLE flowers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    color TEXT NOT NULL,
    price REAL NOT NULL,
    description TEXT,
    image TEXT NOT NULL,
    category_id INTEGER NOT NULL,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE occasions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT
);

CREATE TABLE flower_occasions (
    flower_id INTEGER NOT NULL,
    occasion_id INTEGER NOT NULL,
    PRIMARY KEY (flower_id, occasion_id),
    FOREIGN KEY (flower_id) REFERENCES flowers(id),
    FOREIGN KEY (occasion_id) REFERENCES occasions(id)
);

INSERT INTO categories (name) VALUES
('Grieztie ziedi'),
('Telpaugi'),
('Pavasara ziedi'),
('Dārza puķes');

INSERT INTO flowers (name, color, price, description, image, category_id) VALUES
('Roze', 'Sarkana', 2.50, 'Klasiska puķe, ko bieži dāvina svētkos un īpašos brīžos.', 'roze.jpg', 1),
('Lilija', 'Balta', 3.00, 'Eleganta un smaržīga puķe, kas labi izskatās pušķos.', 'lilija.jpg', 1),
('Tulpe', 'Dzeltena', 1.50, 'Pavasara zieds, kas simbolizē svaigumu un prieku.', 'tulpe.jpg', 3),
('Orhideja', 'Violeta', 5.50, 'Dekoratīvs telpaugs ar spilgtiem ziediem un ilgu ziedēšanas laiku.', 'orhideja.jpg', 2);

INSERT INTO occasions (name, description) VALUES
('Dzimšanas diena', 'Puķes, ko var dāvināt dzimšanas dienā.'),
('Izlaidums', 'Puķes, kas piemērotas izlaiduma sveikšanai.'),
('Mātes diena', 'Maigas un skaistas puķes Mātes dienai.'),
('Mājas dekorēšana', 'Puķes, kas labi iederas mājas interjerā.');

INSERT INTO flower_occasions (flower_id, occasion_id) VALUES
(1, 1),
(1, 3),
(2, 2),
(2, 4),
(3, 1),
(3, 3),
(4, 1),
(4, 4);
